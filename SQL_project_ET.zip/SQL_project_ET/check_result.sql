-- Проверка результатов ETL-процесса

set search_path to bank; -- схема, в которой будут выполняться запросы

SELECT * FROM information_schema.tables WHERE table_schema = 'bank'; -- таблицы в схеме bank

SELECT * FROM rep_fraud; -- витрина мошеннических операций

SELECT * FROM metadata; -- метаданные

select * from dwh_fact_transactions; -- хранилище транзакций

select * from dwh_fact_passport_blacklist; -- хранилище черного списка паспортов

select * from dwh_dim_terminals_hist; -- -- хранилище терминалов

SELECT * -- удаленные терминалы 
FROM bank.dwh_dim_terminals_hist 
WHERE deleted_flg = 1; 

SELECT * --  терминалы с измененными данными
FROM bank.dwh_dim_terminals_hist
WHERE terminal_id IN (
    SELECT terminal_id
    FROM bank.dwh_dim_terminals_hist
    GROUP BY terminal_id
    HAVING COUNT(*) > 1
)
ORDER BY terminal_id, effective_from;